package com.sict.mobile.doan.Model.ObjectClas;

public class NhanVien  {


    int MaNV,MaLoaiNV,GioiTinh;
    String TenDN;
    String MatKhau;
    String TenNV;
    String DiaChi;
    String NgaySinh;
    String SoDT;
    String EmailDocQuyen;

    public int getMaNV() {
        return MaNV;
    }

    public void setMaNV(int maNV) {
        MaNV = maNV;
    }

    public int getMaLoaiNV() {
        return MaLoaiNV;
    }

    public void setMaLoaiNV(int maLoaiNV) {
        MaLoaiNV = maLoaiNV;
    }

    public int getGioiTinh() {
        return GioiTinh;
    }

    public void setGioiTinh(int gioiTinh) {
        GioiTinh = gioiTinh;
    }

    public String getTenDN() {
        return TenDN;
    }

    public void setTenDN(String tenDN) {
        TenDN = tenDN;
    }

    public String getMatKhau() {
        return MatKhau;
    }

    public void setMatKhau(String matKhau) {
        MatKhau = matKhau;
    }

    public String getTenNV() {
        return TenNV;
    }

    public void setTenNV(String tenNV) {
        TenNV = tenNV;
    }

    public String getDiaChi() {
        return DiaChi;
    }

    public void setDiaChi(String diaChi) {
        DiaChi = diaChi;
    }

    public String getNgaySinh() {
        return NgaySinh;
    }

    public void setNgaySinh(String ngaySinh) {
        NgaySinh = ngaySinh;
    }

    public String getSoDT() {
        return SoDT;
    }

    public void setSoDT(String soDT) {
        SoDT = soDT;
    }

    public String getEmailDocQuyen() {
        return EmailDocQuyen;
    }

    public void setEmailDocQuyen(String emailDocQuyen) {
        EmailDocQuyen = emailDocQuyen;
    }



}

