package com.sict.mobile.doan.Presenter.TrangChu.XyLyMenu;

import com.sict.mobile.doan.ConnectInternet.DownloadJSON;
import com.sict.mobile.doan.ConnectInternet.Server;
import com.sict.mobile.doan.Model.ObjectClas.LoaiSanPham;
import com.sict.mobile.doan.Model.TrangChu.XulyMenu.XulyJSONMenu;
import com.sict.mobile.doan.View.TrangChu.ViewXyLyMenu;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class PresenterLogicXuLyMenu implements  IPresenterXuLyMenu {
    ViewXyLyMenu viewXyLyMenu;
    public  PresenterLogicXuLyMenu(ViewXyLyMenu viewXyLyMenu){
        this.viewXyLyMenu=viewXyLyMenu;

    }
    @Override
    public void LayDanhSachMenu() {
        List<LoaiSanPham> loaiSanPhamList;
        String dataJSON="";
        List<HashMap<String,String>> attrs = new ArrayList<>(  ); // post
        // Lấy bằng phường thức get
      // String  duongdan="http://"+ Server.Serve +"/weblazada/loaisanpham.php?maloaicha=0";

    //  DownloadJSON  downloadJSON = new DownloadJSON( duongdan );
        // endGet
        //lấy post
        String duongdan=Server.Menuloaisanpham;
        HashMap<String,String> hsMaLoaiCha= new HashMap<>(  );
        hsMaLoaiCha.put( "maloaicha","0" );
        attrs.add( hsMaLoaiCha );
        DownloadJSON downloadJSON = new DownloadJSON( duongdan,attrs );

        downloadJSON.execute(  );

        try {
            dataJSON = downloadJSON.get();
            XulyJSONMenu  xulyJSONMenu = new XulyJSONMenu();
           loaiSanPhamList = xulyJSONMenu.ParerJSONMenu( dataJSON );
     viewXyLyMenu.HienThiDanhSachMenu( loaiSanPhamList );

        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

}
