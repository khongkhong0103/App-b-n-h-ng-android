package com.sict.mobile.doan.Adapter;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.sict.mobile.doan.View.DangNhap_DangKy.Fragment.FragmentDangKy;
import com.sict.mobile.doan.View.DangNhap_DangKy.Fragment.FragmentDangNhap;

public class ViewPageAdapterDangNhap extends FragmentPagerAdapter {
    public ViewPageAdapterDangNhap(FragmentManager fm) {
        super( fm );
    }

    @Override
    public Fragment getItem(int position) {
        switch (position){
            case 0:
                FragmentDangNhap framentDangNhap = new FragmentDangNhap();
                return  framentDangNhap;
            case 1:
                FragmentDangKy fragmentDangKy = new FragmentDangKy();
                return  fragmentDangKy;

                default: return null;
        }

    }

    @Override
    public int getCount() {
        return 2;
    }

     public CharSequence getPageTitle(int position){
         switch (position){
             case 0:

                 return  "Đăng nhập";
             case 1:

                 return  "Đăng ký";

             default: return null;
         }
     }
}
