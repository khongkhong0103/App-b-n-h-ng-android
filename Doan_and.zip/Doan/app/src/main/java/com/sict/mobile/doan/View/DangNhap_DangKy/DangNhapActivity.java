package com.sict.mobile.doan.View.DangNhap_DangKy;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.sict.mobile.doan.Adapter.ViewPageAdapterDangNhap;
import com.sict.mobile.doan.R;
import  androidx.appcompat.widget.Toolbar;
public class DangNhapActivity extends AppCompatActivity {
    TabLayout tabLayout;
    ViewPager viewPager;
    Toolbar toolbar;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.layout_dangnhap );

        tabLayout= (TabLayout) findViewById( R.id.tabDangNhap );
        viewPager =(ViewPager) findViewById( R.id.viewpagerDangNhap);
        toolbar =(Toolbar) findViewById( R.id.toolbarDangNhap );

       setSupportActionBar( toolbar );

        ViewPageAdapterDangNhap  viewPageAdapterDangNhap = new ViewPageAdapterDangNhap( getSupportFragmentManager() );
        viewPager.setAdapter( viewPageAdapterDangNhap );
        viewPageAdapterDangNhap.notifyDataSetChanged();

        tabLayout.setupWithViewPager( viewPager );
    }


}
