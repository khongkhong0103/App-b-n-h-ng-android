package com.sict.mobile.doan.View.TrangChu;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.sict.mobile.doan.R;

public class textActivity extends AppCompatActivity  implements View.OnClickListener {
        EditText editMaloaicha;
        Button btnLayDuLieu;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.text_layout );

        editMaloaicha =(EditText) findViewById( R.id.edMaloaiCha );
        btnLayDuLieu =(Button) findViewById( R.id.btnLayDuLieu );

        btnLayDuLieu.setOnClickListener( this );
    }

    @Override
    public void onClick(View v) {
        String maloaicha = editMaloaicha.getText().toString();
        // địa chi local genymotion  10.0.3.2
        // địa chỉ máy thật  ipconfig/all
        
    }

    public class DloadJSON extends AsyncTask<String,Void,String>{

        @Override
        protected String doInBackground(String... strings) {
            return null;
        }
    }
}
