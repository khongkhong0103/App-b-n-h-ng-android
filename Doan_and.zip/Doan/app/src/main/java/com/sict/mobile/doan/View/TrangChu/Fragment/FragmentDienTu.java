package com.sict.mobile.doan.View.TrangChu.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.sict.mobile.doan.R;

public class FragmentDienTu extends Fragment {

    public View onViewCreated(LayoutInflater inflater, @Nullable ViewGroup container , @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate( R.layout.layout_dientu,container,false);
        return view;
    }
}
