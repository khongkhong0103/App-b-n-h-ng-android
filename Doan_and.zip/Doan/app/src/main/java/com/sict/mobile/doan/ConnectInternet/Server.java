package com.sict.mobile.doan.ConnectInternet;

public class Server {
    public  static String Serve ="10.0.3.2";
    //192.168.1.2
    //10.0.3.2
    public  static String Menuloaisanpham ="Http://"+Serve+"/weblazada/loaisanpham.php";
}
