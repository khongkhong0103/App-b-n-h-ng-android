package com.sict.mobile.doan.View.TrangChu;

import com.sict.mobile.doan.Model.ObjectClas.LoaiSanPham;

import java.util.List;

public interface ViewXyLyMenu  {
    void HienThiDanhSachMenu(List<LoaiSanPham> loaiSanPhamList);
}
