package com.sict.mobile.doan.View.DangNhap_DangKy;

public interface ViewDangKy {
    void DangKyThangCong();
    void DangKyThatBai();

}
