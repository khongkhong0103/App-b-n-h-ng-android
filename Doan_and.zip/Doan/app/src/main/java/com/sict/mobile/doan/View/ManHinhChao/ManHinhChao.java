package com.sict.mobile.doan.View.ManHinhChao;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.sict.mobile.doan.R;
import com.sict.mobile.doan.View.TrangChu.TrangchuActivity;


public class ManHinhChao  extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.manhinhchao_layout );

        Thread  thread = new Thread( new Runnable() {
            @Override
            public void run() {
                try{
                        Thread.sleep( 1000 );
                }catch (Exception e)
                {

                }
             finally {
                    Intent itrangchu = new Intent( ManHinhChao.this, TrangchuActivity.class);
                    startActivity( itrangchu );
                }
            }
        } );
        thread.start();
    }
}
