package com.sict.mobile.doan.Presenter.DangKy;

import com.sict.mobile.doan.Model.ObjectClas.NhanVien;

public interface IPresentterDangKy {
    void ThucHienDangKy(NhanVien nhanvien);
}
