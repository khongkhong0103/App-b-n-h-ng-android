package com.sict.mobile.doan.CustomView;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputType;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;

import androidx.core.content.ContextCompat;

import com.google.android.material.textfield.TextInputLayout;
import com.sict.mobile.doan.R;

import java.lang.reflect.Type;

@SuppressLint("AppCompatCustomView")
public class PasswordText extends EditText {
    Drawable eys,eysStrike;
    Boolean visible=false;
    Boolean useStrike = false;
    Drawable drawable;
    Boolean useValidate = false;
    int ALPHA =(int )(255 * .55f);
    public PasswordText(Context context) {
        super( context );khoitao( null );
    }

    public PasswordText(Context context, AttributeSet attrs) {
        super( context, attrs );
        khoitao( attrs );
    }

    public PasswordText(Context context, AttributeSet attrs, int defStyleAttr) {
        super( context, attrs, defStyleAttr );
        khoitao( attrs );
    }
        @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public PasswordText(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super( context, attrs, defStyleAttr, defStyleRes );
        khoitao( attrs );
    }

    private void khoitao(AttributeSet attr){
        if (attr != null){
            TypedArray array = getContext().getTheme().obtainStyledAttributes( attr,R.styleable.PasswordText,0,0 );
            //lay useStrike xml
            this.useStrike= array.getBoolean( R.styleable.PasswordText_useStrike,false );
            this.useValidate= array.getBoolean( R.styleable.PasswordText_useValidate,false );
        }
        eys = ContextCompat.getDrawable( getContext(), R.drawable.ic_passhien ).mutate();
        eysStrike = ContextCompat.getDrawable( getContext(),R.drawable.ic_passan ).mutate();
 // bắt lỗi passework
//        if (this.useValidate){
//            setOnFocusChangeListener( new OnFocusChangeListener() {
//                @Override
//                public void onFocusChange(View v, boolean hasFocus) {
//                   // Log.d( "Kiemta",hasFocus + "" );
//                    if(!hasFocus){
//                      String chuoi=   getText().toString();
//                        TextInputLayout textInputLayout = (TextInputLayout)v.getParent();
//                        textInputLayout.setErrorEnabled( true );
//                        textInputLayout.setError( "Lỗi rồi !" );
//                    }
//                }
//            } );
//        }

        caidat();
    }

    private  void caidat(){
        setInputType( InputType.TYPE_CLASS_TEXT | (visible? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD) );//ẩn
        Drawable[] drawables = getCompoundDrawables(); //Trả về các drawable cho các đường viền trái, trên, phải và dưới cùng.
        drawable = useStrike && visible ? eysStrike : eys;
        drawable.setAlpha( ALPHA);
        setCompoundDrawablesRelativeWithIntrinsicBounds( drawables[0],drawables[1],drawable,drawables[3] );
    }

    // chuyển động màn hình cảm ứng.
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(event.getAction()==MotionEvent.ACTION_UP && event.getX() >= getRight()-drawable.getBounds().width()){
                visible = !visible;
                caidat();

            invalidate();//Kiểm tra lại màn hinh
        }

        //
        return super.onTouchEvent( event );
    }
}
