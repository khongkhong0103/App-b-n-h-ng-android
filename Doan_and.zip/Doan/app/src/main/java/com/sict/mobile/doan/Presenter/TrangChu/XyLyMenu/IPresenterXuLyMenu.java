package com.sict.mobile.doan.Presenter.TrangChu.XyLyMenu;

public interface IPresenterXuLyMenu {
    void LayDanhSachMenu();
}
