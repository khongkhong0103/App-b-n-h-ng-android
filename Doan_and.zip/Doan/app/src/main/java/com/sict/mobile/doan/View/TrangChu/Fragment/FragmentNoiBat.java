package com.sict.mobile.doan.View.TrangChu.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.sict.mobile.doan.Adapter.AdapterNoiBat;
import com.sict.mobile.doan.R;

import java.util.ArrayList;
import java.util.List;

public class FragmentNoiBat extends Fragment {
        RecyclerView recyclerView;
        AdapterNoiBat adapterNoiBat;
    public View onViewCreated(LayoutInflater inflater, @Nullable ViewGroup container , @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate( R.layout.layout_noibat,container,false);

        recyclerView=(RecyclerView) view.findViewById( R.id.recyleNoiBat );
        List<String> dulieu = new ArrayList<>(  );
        for(int i=0;i<20;i++){
            String ten ="Noi bat "+i;
            dulieu.add( ten );

        }
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager( getActivity() );
        adapterNoiBat = new AdapterNoiBat( getActivity(),dulieu );

        recyclerView.setLayoutManager( layoutManager );
        recyclerView.setAdapter( adapterNoiBat );
        adapterNoiBat.notifyDataSetChanged();
        return view;
    }
}
