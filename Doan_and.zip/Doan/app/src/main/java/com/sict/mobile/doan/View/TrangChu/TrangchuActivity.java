package com.sict.mobile.doan.View.TrangChu;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ExpandableListView;
import android.widget.LinearLayout;
//import android.widget.Toolbar;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.tabs.TabLayout;
import com.sict.mobile.doan.Adapter.ExpanAdapter;
import com.sict.mobile.doan.Adapter.ViewPageAdapter;
import com.sict.mobile.doan.Model.ObjectClas.LoaiSanPham;
import com.sict.mobile.doan.Presenter.TrangChu.XyLyMenu.PresenterLogicXuLyMenu;
import com.sict.mobile.doan.R;
import com.sict.mobile.doan.View.DangNhap_DangKy.DangNhapActivity;

import  androidx.appcompat.widget.Toolbar;
import androidx.core.view.ViewCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager.widget.ViewPager;

import java.util.List;

public class TrangchuActivity  extends AppCompatActivity implements  ViewXyLyMenu, AppBarLayout.OnOffsetChangedListener {

   public static final String SERVER_NAME = "http://192.168.1.11/weblazada/loaisanpham.php";
   public static final String SERVER= "http://192.168.1.11/weblazada";

    Toolbar toolbar;
    TabLayout tabLayout;
    ViewPager viewPager;
    DrawerLayout drawerLayout;

    CollapsingToolbarLayout collapsingToolbarLayout;
    AppBarLayout appBarLayout;
 //gắng lên actionBar
    ActionBarDrawerToggle drawerToggle; // 3 gạch

    ExpandableListView expandableListView;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.trangchu_layout );

        toolbar = (Toolbar) findViewById( R.id.toolbar );
        tabLayout = (TabLayout) findViewById( R.id.tabs );
        viewPager =(ViewPager) findViewById( R.id.viewPager );
        drawerLayout = (DrawerLayout) findViewById( R.id.drawerLayout );
        appBarLayout =(AppBarLayout ) findViewById( R.id.appbar );
        collapsingToolbarLayout =(CollapsingToolbarLayout)findViewById( R.id.collapsing_toolbar );
        expandableListView =(ExpandableListView) findViewById( R.id.epMenu );


        toolbar.setTitle( "" );
        setSupportActionBar(toolbar);

        drawerToggle = new ActionBarDrawerToggle( this,drawerLayout, R.string.open ,R.string.close);
        //gắn vào toolbar
        drawerLayout.addDrawerListener( drawerToggle );

        //Mở lên 3 gạch
        getSupportActionBar().setHomeButtonEnabled( true );
        getSupportActionBar().setDisplayHomeAsUpEnabled( true );
        drawerToggle.syncState(); // đồng bộ các dữ liêu drawerlayout

        ViewPageAdapter adapter = new ViewPageAdapter( getSupportFragmentManager() );
        viewPager.setAdapter( adapter );
        tabLayout.setupWithViewPager( viewPager );



       PresenterLogicXuLyMenu logicXuLyMenu = new PresenterLogicXuLyMenu( this );
       logicXuLyMenu.LayDanhSachMenu();

        appBarLayout.addOnOffsetChangedListener( this );
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate( R.menu.menutrangchu,menu );
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(drawerToggle.onOptionsItemSelected( item )){
            return  true;
        }

        // sự kiện clik vào đăng nhập
        int id = item.getItemId();
        switch ( id){
            case R.id.itDangNhap:
            Intent itDangNhap = new Intent( this, DangNhapActivity.class );// chuyển giao diẹn
                startActivity( itDangNhap );

        }
        return  true;
    }

    @Override
    public void HienThiDanhSachMenu(List<LoaiSanPham> loaiSanPhamList) {
      // Log.d("kiemtra",loaiSanPhamList.get( 0 ).getTENLOAISP());
        ExpanAdapter expandAdater = new ExpanAdapter(this,loaiSanPhamList);
        expandableListView.setAdapter(expandAdater);
        expandAdater.notifyDataSetChanged();
    }


    @Override
    public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
        if(collapsingToolbarLayout.getHeight() + verticalOffset <= 1.5 * ViewCompat.getMinimumHeight( collapsingToolbarLayout ))
        {
            LinearLayout linearLayout =(LinearLayout) appBarLayout.findViewById( R.id.lnSearch );
           linearLayout.animate().alpha( 0 ).setDuration( 1000 );
        }else {
            LinearLayout linearLayout=(LinearLayout)appBarLayout.findViewById( R.id.lnSearch );
            linearLayout.animate().alpha( 1 ).setDuration( 1000 );
        }
    }
}
