package com.sict.mobile.doan.View.DangNhap_DangKy.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.sict.mobile.doan.R;

import java.util.Arrays;

public class FragmentDangNhap extends Fragment implements View.OnClickListener
{
    Button btnDangNhapFacebook;
    CallbackManager callbackManager;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View  view = inflater.inflate( R.layout.layout_fragment_dangnhap,container,false );

//        try {
//            PackageInfo info = getActivity().getPackageManager().getPackageInfo(
//                    "com.sict.mobile.doan",
//                    PackageManager.GET_SIGNATURES);
//            for (Signature signature : info.signatures) {
//                MessageDigest md = MessageDigest.getInstance("SHA");
//                md.update(signature.toByteArray());
//                Log.d("kiemtra", Base64.encodeToString(md.digest(), Base64.DEFAULT));
//            }
//        } catch (PackageManager.NameNotFoundException e) {
//
//        } catch (NoSuchAlgorithmException e) {
//
//        }
      FacebookSdk.sdkInitialize( getContext().getApplicationContext() );

        callbackManager=CallbackManager.Factory.create();
        LoginManager.getInstance().registerCallback( callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                Log.d( "kiemtra","thanh cong" );
            }

            @Override
            public void onCancel() {
                Log.d( "kiemtra","thoat" );
            }

            @Override
            public void onError(FacebookException error) {
                Log.d( "kiemtra","loi" );
            }
        } );
        btnDangNhapFacebook=(Button) view.findViewById(R.id.btnDangNhapFacebook);

        btnDangNhapFacebook.setOnClickListener( this );
        return view;


    }

    @Override
    public void onClick(View view) {
        LoginManager.getInstance().logInWithReadPermissions( FragmentDangNhap.this, Arrays.asList("public_profile") );
    }

     // nhấm ok chạy vào onActivityResult
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult( requestCode, resultCode, data );
        callbackManager.onActivityResult( requestCode,resultCode,data );
    }
}
